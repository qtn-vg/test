<?php
require 'db.class.php';
$DB = new DB();
?><!DOCTYPE html>
<!--Indique au navigateur qu’il s’agit d’une page web HTML-->
<html>
<!--englobe tout le code de la page-->

<head>
	<!--informations supplémentaires qui n’apparaissent pas directement sur la page-->
	<title> TS2 | Panier</title>
	<!--Ceci est le nom de la page, il est affiché sur le nom de l'onglet-->
	<meta charset="UTF-8">
	<!--Permet de gérer les accents-->
	<link rel="stylesheet" href="panier.css">
  	<link rel="stylesheet" href="menu.css">
	<!--lien avec la fiche CSS-->
</head>

<body>
	<!--partie principale de la page-->
  <header><a href="index.html" id="logo"></a> <!--href sert à faire un lien de retour ; id sert à attribuer une classe-->
	  <nav><!--section d'une page ayant des liens vers d'autres pages-->
		  <a href="#" id="menu-icon"></a>
		  <ul><!--liste d'éléments-->
		  	<li>
          <li style="list-style: none; display: inline"></li>
				  <a href="voyages.html">Nos voyages 🛫</a>
          <li style="list-style: none; display: inline"></li>
			  </li>
			  <li>
          <li style="list-style: none; display: inline"></li>
				  <a href="produits.html">Nos produits essentiels 👒</a>
          <li style="list-style: none; display: inline"></li>
			  </li>
			  <li>
          <li style="list-style: none; display: inline"></li>
				  <a href="nous.html">A propos de nous 👀</a>
          <li style="list-style: none; display: inline"></li>
			  </li>
			  <li>
          <li style="list-style: none; display: inline"></li>
				  <a href="contact.html">Contact 👋</a>
          <li style="list-style: none; display: inline"></li>
			  </li>
			</ul>
	  </nav>
  </header>
  <h1>
    Mon panier :
  </h1>

</body>