<?php
function creationPanier(){ //On créé la fonction panier
   if (!isset($_SESSION['panier'])){ //Si le panier n'existe pas, on le créé
      $_SESSION['panier']=array(); //Création d'une variable panier. Le panier ne traitera que certaines propriété du produit :
      $_SESSION['panier']['libelleProduit'] = array(); //Le nom
      $_SESSION['panier']['qteProduit'] = array(); //La quantité
      $_SESSION['panier']['prixProduit'] = array();//Le prix
      $_SESSION['panier']['verrou'] = false;
   }//Permettra de vérouiller toute action sur le panier, notamment en mode paiement, qui serait un prolongement envisagé
   return true;
}
function ajouterArticle($libelleProduit,$qteProduit,$prixProduit){ //Le but est de créer une focntion pour ajouter un article

   //On vérifie que le panier existe bien à l'aide de notre première fonction
   if (creationPanier() && !isVerrouille())
   {
      //On vérifie si le produit est déja présent dans le panier. Si oui, on augmente sa quantité dans le panier.
      $positionProduit = array_search($libelleProduit,  $_SESSION['panier']['libelleProduit']);

      if ($positionProduit !== false)
      {
         $_SESSION['panier']['qteProduit'][$positionProduit] += $qteProduit ;
      }
      else
      {
         //Sinon on ajoute le produit au panier
         array_push( $_SESSION['panier']['libelleProduit'],$libelleProduit);
         array_push( $_SESSION['panier']['qteProduit'],$qteProduit);
         array_push( $_SESSION['panier']['prixProduit'],$prixProduit);
      }
   }
   else
   echo "Un problème est survenu veuillez contacter l'administrateur du site."; //Si le panier n'existe pas, ce message s'affiche
}
function supprimerArticle($libelleProduit){ //Le but est de créer une fonction pour suprrimer un article.
   //On vérifie que le panier existe déjà 
   if (creationPanier() && !isVerrouille())
   {
      //On crée un panier « tampon » qui va être notre panier sans les éléments à supprimer.
      $tmp=array();
      $tmp['libelleProduit'] = array();
      $tmp['qteProduit'] = array();
      $tmp['prixProduit'] = array();
      $tmp['verrou'] = $_SESSION['panier']['verrou'];

      for($i = 0; $i < count($_SESSION['panier']['libelleProduit']); $i++)//On remplit le panier « tampon ».
      {
         if ($_SESSION['panier']['libelleProduit'][$i] !== $libelleProduit)
         {
            array_push( $tmp['libelleProduit'],$_SESSION['panier']['libelleProduit'][$i]);
            array_push( $tmp['qteProduit'],$_SESSION['panier']['qteProduit'][$i]);
            array_push( $tmp['prixProduit'],$_SESSION['panier']['prixProduit'][$i]);
         }

      }
      //On réaffecte notre panier via les valeurs du panier tampon.
      $_SESSION['panier'] =  $tmp;
      //On efface notre panier temporaire
      unset($tmp);
   }
   else
   echo "Un problème est survenu veuillez contacter l'administrateur du site.";//Si le panier n'existe pas, ce message s'affiche
}
function modifierQTeArticle($libelleProduit,$qteProduit){//Le but est de pouvoir modifier la quantité d'un article
   //On vérifie l'existance du panier
   if (creationPanier() && !isVerrouille())
   {
      //Si la quantité demandée pour un produit est supérieure à on modifie la quantité. Sinon on supprime l'article
      if ($qteProduit > 0)
      {
         //Recherche du produit dans le panier
         $positionProduit = array_search($libelleProduit,  $_SESSION['panier']['libelleProduit']);

         if ($positionProduit !== false)//On modifie la quantité du produit
         {
            $_SESSION['panier']['qteProduit'][$positionProduit] = $qteProduit ;
         }
      }
      else
      supprimerArticle($libelleProduit); //Si la quantité est négative ou nulle, on supprime l'article
   }
   else
   echo "Un problème est survenu veuillez contacter l'administrateur du site.";//Si le panier n'existe pas, ce message s'affiche
}
function MontantGlobal(){ //Le but est de renvoyer le total du panier
   $total=0; //Initialisation à 0
   for($i = 0; $i < count($_SESSION['panier']['libelleProduit']); $i++)
   {
      $total += $_SESSION['panier']['qteProduit'][$i] * $_SESSION['panier']['prixProduit'][$i];
   }
   return $total;//Retour du montant total
}
function isVerrouille(){ //Fonction permettant de vérifier le verrou sans affecter le panier
   if (isset($_SESSION['panier']) && $_SESSION['panier']['verrou'])
   return true;
   else
   return false;
}
function compterArticles()//Fonction permettant de compter le nombre de catégories d'articles présent dans le panier. Prolongement possible: compter tout les articles
{
   if (isset($_SESSION['panier']))
   return count($_SESSION['panier']['libelleProduit']);
   else
   return 0;

}
function supprimePanier(){ //Fonction permettant de supprimer entierment le panier
   unset($_SESSION['panier']);
}

?>